#include <algorithm>

#include "algorithm.h"
#include "graphics.h"

bool DEBUG_FLAG=false;

/////////////////////////////////////////////////////////////////

void testFunction(){
	cout << "test" << endl;
}
