#ifndef __ALGORITHM_H__
#define __ALGORITHM_H__

#include <set>
#include <stack>
#include <ctime>
#include <string>
#include <iostream>
#include <algorithm>
#include <vector>
#include <deque>
#include <set>


using namespace std;

/////////////////////////////////////////////////////

//test function

void testFunction();


#endif
